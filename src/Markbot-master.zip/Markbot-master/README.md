# Markbot
An AI powered marketing and branding tool made for all businesses.
